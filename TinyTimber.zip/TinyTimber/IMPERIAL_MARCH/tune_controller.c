#include "application.h"

extern Can can0;

void change_key(Tune_Controller *self, int key) {
	self->key = key;
}

void change_tempo(Tune_Controller *self, int tempo) {
	self->tempo = tempo;
}

void change_canon_delay_n(Tune_Controller *self, int n) {
	self->canon_delay_n = n;
}

int get_index(Tune_Controller *self, int unused) {
	return self->index;
}

int get_channel(Tune_Controller *self, int unused) { // method needed for gap_mute
    return self->channel;
}

void note_scheduler(Tune_Controller *self, int channel) {
    if( (self->channel != channel) || !self->playing )
        return;
    if(self->canon_tempo_change) { /* send CAN message with tempo and index */
        CANMsg msg;
        msg.msgId = 2;
        msg.nodeId = SYNC(&app, get_nodeId, 0);
        msg.length = 3;
        msg.buff[0] = self->tempo;
        msg.buff[1] = self->index;
        msg.buff[2] = 0;
        self->canon_tempo_change = 0;
        CAN_SEND(&can0, &msg);
    }
    int new_period = self->periods[self->frequency_indices[self->index] + 10 + self->key];
    ASYNC(&pg0, change_period, new_period);
    ASYNC(&pg0, gap_unmute, self->channel);
//---------------------------------------------------------------------------------
    Time next_frequency_update = MSEC( (60000/self->tempo) * ((float)self->beat_pattern[self->index]/500) );
//--------------------------------------------------------------------------------
    self->index = (self->index + 1) % 73;
    AFTER(next_frequency_update - MSEC(50), &pg0, gap_mute, self->channel);
    AFTER(next_frequency_update, self, note_scheduler, self->channel);
}

void canon_planner(Tune_Controller *self, int index) {
    self->channel++;
	self->playing = 0;
    self->index = index;
    int nodeId = SYNC(&app, get_nodeId, 0);
    Time delay = MSEC( (nodeId * self->canon_delay_n) * (60000/self->tempo) );
	ASYNC(&pg0, canon_mute, 0);
    AFTER(delay, self, play, self->channel); // update: going via play is unnecessary(?) -- call note_scheduler directly
}

void canon_play(Tune_Controller *self, int canon_delay) {
	self->canon_delay_n = canon_delay;
	ASYNC(self, canon_planner, 0);
}

void set_canon_tempo_change(Tune_Controller *self, int canon_tempo_change) {
    self->canon_tempo_change = canon_tempo_change;
}

void play(Tune_Controller *self, int unused) {
	if(!self->playing)
	{
		self->playing = 1;
		ASYNC(&pg0, canon_unmute, 0);
		ASYNC(self, note_scheduler, self->channel);
	}
}

void play_pause(Tune_Controller *self, int unused) {
	if(!self->playing)
	{
		self->playing = 1;
		ASYNC(self, note_scheduler, self->channel);
	}
	else
	{
		self->playing = 0;
	}
}

int is_canon(Tune_Controller *self, int unused) {
	return (self->canon > 0);
}
