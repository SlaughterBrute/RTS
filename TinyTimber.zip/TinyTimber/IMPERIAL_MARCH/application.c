#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdlib.h>
#include <stdio.h>
#include "application.h"
#include <string.h>

App app = { initObject(), 0, 'X',0,0,1};
//Tune_Controller brother_john_controller = { initObject(), 0, 120, {2024,1911,1803,1702,1607,1516,1431,1351,1275,1203,1136,1072,1012,955,901,851,803,758,715,675,637,601,568,536,506}, {0,2,4,0,0,2,4,0,4,5,7,4,5,7,7,9,7,5,4,0,7,9,7,5,4,0,0,-5,0,0,-5,0}, {'a','a','a','a','a','a','a','a','a','a','b','a','a','b','c','c','c','c','a','a','c','c','c','c','a','a','a','a','b','a','a','b'}, 0, 0, 0, 0, 1, 0 };
Tune_Controller brother_john_controller = { initObject(), 0, 120, {0,1911,1803,1702,1607,1516,1431,1351,1275,1203,1136,1072,1012,955,901,851,803,758,715,675,637,601,568,536,506}, {0, 0 ,0,-4, 3, 0, -4, 3, 0,/**/-10,/**/7, 7, 7, 8, 3, -1, -4, 3, 0,/**/-10,/**/12, 0, 0, 12, 11, 10, 9, 8, 9,/**/-10,/**/1, 6, 5, 4, 3, 1, 3,/**/-10,/**/-4, -1,-4, 0, 3, 0, 3, 7,/**/12, 0, 0, 12, 11, 10, 9, 8, 9,/**/-10,/**/1, 6, 5, 4, 3, 1, 3,/**/-10,/**/-4,-1,-4, 3, 0, -4, 3, 0, -10}, {500,500,500,350,150,500,350,150,650,/**/150,/**/500,500,500,350,150,500,350,150,650,/**/150,/**/500,300,150,400,200,200,125,125,250,/**/250,/**/250,400,200,200,125,125,250,/**/250,/**/125,500,375,125,500,375,125,650,/**/500,300,150,400,200,200,125,125,250,/**/250,/**/250,400,200,200,125,125,250,/**/250,/**/250,500,375,125,500,375,125,650,/**/1000}, 0, 0, 0, 0, 0, 0 };
void reader(App*, int);
void receiver(App*, int);

Serial sci0 = initSerial(SCI_PORT0, &app, reader);

Can can0 = initCan(CAN_PORT0, &app, receiver);

void receiver(App *self, int unused) {
    CANMsg msg;
    CAN_RECEIVE(&can0, &msg);
    SCI_WRITE(&sci0, "Can msg received: ");
    SCI_WRITE(&sci0, msg.buff);
	SCI_WRITE(&sci0, "\n");
	
	if(self->nodeId)
	{
		switch(msg.msgId)
		{
			case 1:
				ASYNC(&brother_john_controller, play_pause, 0);
				break;
			case 2:
				if(msg.buff[0] < 60 || msg.buff[0] > 240)
					break;
				ASYNC(&brother_john_controller, change_tempo, msg.buff[0]);
				if(SYNC(&brother_john_controller, is_canon, 0))
				{
					if(msg.buff[1] >= 0 && msg.buff[1] <= 31)
						ASYNC(&brother_john_controller, canon_planner, msg.buff[1]);
				}
				break;
			case 3:
				if((signed char)msg.buff[0] >= -5 && (signed char)msg.buff[0] <= 5)
					ASYNC(&brother_john_controller, change_key, (signed char)msg.buff[0]);
				break;
			case 4:
				if(msg.buff[0] >= 0 && msg.buff[0] <= 0x14)
					ASYNC(&pg0, set_volume, msg.buff[0]);
				break;
			case 5:
				ASYNC(&pg0, toggle_master_mute, 0);
				break;
			case 6:
				ASYNC(&brother_john_controller, canon_play, msg.buff[0]);
		}
	}
}

void reader(App *self, int c) {
    SCI_WRITE(&sci0, "Rcv: \'");
    SCI_WRITECHAR(&sci0, c);
    SCI_WRITE(&sci0, "\'\n");
	
	CANMsg msg;
	
	char cc = (char) c;
	if(cc == 'q' || cc == 'a') /* increase/decrease volume */
	{
		self->buffer_index = 0;
		ASYNC(&pg0, change_volume, c);
	}
	else if(cc == 'v') /* set volume */
	{
		self->buffer[self->buffer_index] = '\0';
		self->buffer_value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->buffer_value);
		if(self->buffer_value >= 0 && self->buffer_value <= 0x14)
		{
			ASYNC(&pg0, set_volume, self->buffer_value);
			msg.msgId = 4;
			msg.nodeId = self->nodeId;
			msg.length = 2;
			msg.buff[0] = (unsigned char) self->buffer_value;
			msg.buff[1] = 0;
			CAN_SEND(&can0, &msg);
		}
		self->buffer_index = 0;
	}
	else if(cc == 'm') /* mute/unmute */
	{
		self->buffer_index = 0;
		ASYNC(&pg0, toggle_master_mute, 0);
		msg.msgId = 5;
		msg.nodeId = self->nodeId;
		msg.length = 0;
		CAN_SEND(&can0, &msg);
	}
	else if(cc == 'p' && !self->nodeId) /* play/pause */
	{
		self->buffer_index = 0;
		ASYNC(&brother_john_controller, play_pause, 0);
//		msg.msgId = 1;
//		msg.nodeId = self->nodeId;
//		msg.length = 0;
//		CAN_SEND(&can0, &msg);
	}
	else if(cc == 'c' && !self->nodeId) /* play canon */
	{
		self->buffer[self->buffer_index] = '\0';
		self->buffer_value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->buffer_value);
		
		ASYNC(&brother_john_controller, canon_planner, 0);
		msg.msgId = 6;
		msg.nodeId = self->nodeId;
		self->buffer_index = 0;
		msg.length = 2;
		msg.buff[0] = (unsigned char) self->buffer_value;
		msg.buff[1] = 0;
		CAN_SEND(&can0, &msg);
	}
	else if(cc == 't' && !self->nodeId) /* change tempo */
    {
        self->buffer[self->buffer_index] = '\0';
        self->buffer_value = atoi(self->buffer);
        snprintf(self->buffer, 100, "%d", self->buffer_value);
        
        if(self->buffer_value >= 60 && self->buffer_value <= 240)
        {
            ASYNC(&brother_john_controller, change_tempo, self->buffer_value);
            if(SYNC(&brother_john_controller, is_canon, 0))
            {
                ASYNC(&brother_john_controller, set_canon_tempo_change, self->buffer_value); // add state variable canon_tempo_change to Tune_Controller
            }
            else
            {
                msg.msgId = 2;
                msg.nodeId = self->nodeId;
                msg.length = 2;
                msg.buff[0] = (unsigned char) self->buffer_value;
                msg.buff[1] = 0;
                CAN_SEND(&can0, &msg);
            }
            
        }
        self->buffer_index = 0;
    }
	else if(cc == 'k' && !self->nodeId) /* change key */
	{
		self->buffer[self->buffer_index] = '\0';
		self->buffer_value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->buffer_value);
		if(self->buffer_value >= -5 && self->buffer_value <= 5)
		{
			ASYNC(&brother_john_controller, change_key, self->buffer_value);
			msg.msgId = 3;
			msg.nodeId = self->nodeId;
			msg.length = 2;
			msg.buff[0] = (unsigned char) self->buffer_value;
			msg.buff[1] = 0;
			CAN_SEND(&can0, &msg);
		}
		self->buffer_index = 0;
	}
	else if(cc == 'n' && !self->nodeId) /* set canon delay */
	{
		self->buffer[self->buffer_index] = '\0';
		self->buffer_value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->buffer_value);
		if(self->buffer_value >= 0)
		{
			ASYNC(&brother_john_controller, change_canon_delay_n, self->buffer_value);
			msg.msgId = 4;
			msg.nodeId = self->nodeId;
			msg.length = 2;
			msg.buff[0] = (unsigned char) self->buffer_value;
			msg.buff[1] = 0;
			CAN_SEND(&can0, &msg);
		}
		self->buffer_index = 0;
	}
	else
	{
		self->buffer[self->buffer_index] = cc;
		self->buffer_index++;
	}
}

int get_nodeId(App *self, int unused)
{
	return self->nodeId;
}

void startApp(App *self, int arg) {
	CANMsg msg;

    CAN_INIT(&can0);
    SCI_INIT(&sci0);
    SCI_WRITE(&sci0, "Program running...\n");
	
	
    msg.msgId = 9;
    msg.nodeId = self->nodeId;
    msg.length = 6;
    msg.buff[0] = 'H';
    msg.buff[1] = 'e';
    msg.buff[2] = 'l';
    msg.buff[3] = 'l';
    msg.buff[4] = 'o';
    msg.buff[5] = 0;
    CAN_SEND(&can0, &msg);
	
	msg.msgId = 9;
    msg.nodeId = self->nodeId;
    msg.length = 7;
    msg.buff[0] = 'F';
    msg.buff[1] = 'r';
    msg.buff[2] = 'i';
    msg.buff[3] = 'e';
    msg.buff[4] = 'n';
	msg.buff[5] = 'd';
    msg.buff[6] = 0;
    CAN_SEND(&can0, &msg);
	
	
	ASYNC(&pg0, generate_pulse, 0);
	ASYNC(&brother_john_controller, note_scheduler, 0);
}

int main() {
    INSTALL(&sci0, sci_interrupt, SCI_IRQ0);
	INSTALL(&can0, can_interrupt, CAN_IRQ0);
    TINYTIMBER(&app, startApp, 0);
    return 0;
}