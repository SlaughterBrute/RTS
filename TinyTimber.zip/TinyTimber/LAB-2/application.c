#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdlib.h>
#include <stdio.h>
#include "application.h"

typedef struct {
    Object super;
    int count;
    char c;
	int buffer_value;
	int buffer_index;
	char buffer[100];
} App;

App app = { initObject(), 0, 'X',0,0};
Tune_Controller brother_john_controller = { initObject(), 0, 120, {2024,1911,1803,1702,1607,1516,1431,1351,1275,1203,1136,1072,1012,955,901,851,803,758,715,675,637,601,568,536,506}, {0,2,4,0,0,2,4,0,4,5,7,4,5,7,7,9,7,5,4,0,7,9,7,5,4,0,0,-5,0,0,-5,0}, {'a','a','a','a','a','a','a','a','a','a','b','a','a','b','c','c','c','c','a','a','c','c','c','c','a','a','a','a','b','a','a','b'}, 0, 0 };


void reader(App*, int);
void receiver(App*, int);

Serial sci0 = initSerial(SCI_PORT0, &app, reader);

Can can0 = initCan(CAN_PORT0, &app, receiver);

void receiver(App *self, int unused) {
    CANMsg msg;
    CAN_RECEIVE(&can0, &msg);
    SCI_WRITE(&sci0, "Can msg received: ");
    SCI_WRITE(&sci0, msg.buff);
}

void reader(App *self, int c) {
    SCI_WRITE(&sci0, "Rcv: \'");
    SCI_WRITECHAR(&sci0, c);
    SCI_WRITE(&sci0, "\'\n");
	
	char cc = (char) c;
	if(cc == 'q' || cc == 'a') /* increase/decrease volume */
	{
		ASYNC(&pg0, change_volume, c);
	}
	else if(cc == 'm') /* mute/unmute */
	{
		ASYNC(&pg0, toggle_master_mute, 0);
	}
	else if(cc == 'k')
	{
		self->buffer[self->buffer_index] = '\0';
		self->buffer_value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->buffer_value);
		self->buffer_index = 0;
		if(self->buffer_value >= -5 && self->buffer_value <= 5)
			ASYNC(&brother_john_controller, change_key, self->buffer_value);
	}
	else if(cc == 't')
	{
		self->buffer[self->buffer_index] = '\0';
		self->buffer_value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->buffer_value);
		self->buffer_index = 0;
		if(self->buffer_value >= 60 && self->buffer_value <= 240)
			ASYNC(&brother_john_controller, change_tempo, self->buffer_value);
	}
	else
	{
		self->buffer[self->buffer_index] = cc;
		self->buffer_index++;
	}
}

void startApp(App *self, int arg) {
	CANMsg msg;

    CAN_INIT(&can0);
    SCI_INIT(&sci0);
    SCI_WRITE(&sci0, "Hello, hello...\n");
	
	
    msg.msgId = 1;
    msg.nodeId = 1;
    msg.length = 6;
    msg.buff[0] = 'H';
    msg.buff[1] = 'e';
    msg.buff[2] = 'l';
    msg.buff[3] = 'l';
    msg.buff[4] = 'o';
    msg.buff[5] = 0;
    CAN_SEND(&can0, &msg);
	
	
	ASYNC(&pg0, generate_pulse, 0);
	ASYNC(&brother_john_controller, note_scheduler, 0);
}

int main() {
    INSTALL(&sci0, sci_interrupt, SCI_IRQ0);
	INSTALL(&can0, can_interrupt, CAN_IRQ0);
    TINYTIMBER(&app, startApp, 0);
    return 0;
}
