#include "application.h"

void change_key(Tune_Controller *self, int key) {
	self->key = key;
}

void change_tempo(Tune_Controller *self, int tempo) {
	self->tempo = tempo;
}

void note_scheduler(Tune_Controller *self, int unused) {
	int new_period = self->periods[self->frequency_indices[self->index] + 10 + self->key];
	ASYNC(&pg0, change_period, new_period);
	ASYNC(&pg0, gap_unmute, 0);
	Time next_frequency_update = MSEC(60000 / self->tempo);
	if(self->beat_pattern[self->index] == 'b') {
		next_frequency_update <<= 1;
	} else if(self->beat_pattern[self->index] == 'c') {
		next_frequency_update >>= 1;
	}
	self->index = (self->index + 1) % 32;
	AFTER(next_frequency_update - MSEC(100), &pg0, gap_mute, 0);
	AFTER(next_frequency_update, self, note_scheduler, 0);
	
}