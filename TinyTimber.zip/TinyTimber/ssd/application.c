#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    Object super;
    int count;
    char c;
	int frequency_indices[32];
	int period[25];
	int index;
	int value;
	char buffer[100];
} App;

App app = { initObject(), 0, 'X', {0,2,4,0,0,2,4,0,4,5,7,4,5,7,7,9,7,5,4,0,7,9,7,5,4,0,0,-5,0,0,5,0}, {2024,1911,1803,1702,1607,1516,1431,1351,1275,1203,1136,1072,1012,955,901,851,803,758,715,675,637,601,568,536,506},0,0};

void reader(App*, int);
void receiver(App*, int);

Serial sci0 = initSerial(SCI_PORT0, &app, reader);

Can can0 = initCan(CAN_PORT0, &app, receiver);

void receiver(App *self, int unused) {
    CANMsg msg;
    CAN_RECEIVE(&can0, &msg);
    SCI_WRITE(&sci0, "Can msg received: ");
    SCI_WRITE(&sci0, msg.buff);
}

void printKey0(App *self, int unused)
{
	for(int n = 0; n < 32; n++)
	{
		snprintf(self->buffer, 100, "%d", self->period[self->frequency_indices[n]+10]);
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
	}
}

void printKey(App *self, int key)
{ 
	for(int n = 0; n < 32; n++)
	{
		snprintf(self->buffer, 100, "%d", self->period[self->frequency_indices[n]+10+key]);
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
	}
}

void reader(App *self, int c) {
    SCI_WRITE(&sci0, "Rcv: \'");
    SCI_WRITECHAR(&sci0, c);
    SCI_WRITE(&sci0, "\'\n");
	
	char cc = (char) c;
	if(cc == 'e')
	{
		self->buffer[self->index] = '\0';
		self->value = atoi(self->buffer);
		snprintf(self->buffer, 100, "%d", self->value);
		SCI_WRITE(&sci0, "Key: ");
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
		self->index = 0;
		ASYNC(self, printKey, self->value);
	}
	else
	{
		self->buffer[self->index] = cc;
		self->index++;
	}
}

/////////////////////////////////////////////////////////////////////////
/* Example: Semaphores in C */
//
//struct call_block;
//typedef struct call_block *Caller;
//
//typedef struct call_block{
//	Caller next;
//	Object *obj;
//	Method meth;
//} CallBlock;
//
//#define initCallBlock() { 0, 0, 0 }
//
///* behövs två metoder för ett call block, insert och remove (enqueie och dequeue) */
//void c_enqueue(Caller c, Caller *queue)
//{
//	Caller prev = NULL, q = *queue;
//	while(q) //find last element in queue
//	{
//		prev = q;
//		q = q->next;
//	}
//	if(prev == NULL)
//		*queue = c;
//	else
//		prev->next = c;
//	c->next = NULL;
//}
//
//Caller c_dequeue(Caller *queue)
//{
//	Caller c = *queue;
//	if(c)
//		*queue = c->next; //remove first element in queue
//	return c;
//}
//
//typedef struct{
//	Object super;
//	int value;
//	Caller queue;
//} Semaphore;
//
//void Wait(Semaphore*, int);
//void Signal(Semaphore*, int);
//
//#define initSemaphore(n) {initObject(), n, 0}
//
//void Wait(Semaphore *self, int c)
//{
//	Caller wakeup = (Caller)c; //type cast back from 'int'
//	if(self->value > 0)
//	{
//		self->value--;
//		ASYNC(wakeup->obj, wakeup->meth, 0);
//	}
//	else
//		c_enqueue(wakeup, &self->queue);
//}
//
//void Signal(Semaphore *self, int unused)
//{
//	if(self->queue)
//	{
//		Caller wakeup = c_dequeue(&self->queue);
//		ASYNC(wakeup->obj, wakeup->meth, 0);
//	}
//	else
//		self->value++;
//}
//
///* Define two identical tasks using the same semaphore */
//Semaphore sem = initSemaphore(1); //binary semaphore
//
//typedef struct{
//	Object super;
//	CallBlock cb; // where call-back information is stored
//} Task;
//
//Task task1 = {initObject(), initCallBlock()};
//Task task2 = {initObject(), initCallBlock()};
//
//void Critical(Task*,int);
//void Non_Critical(Task *self, int unused)
//{
//	//... non critical
//	self->cb.obj = self;
//	self->cb.meth = Critical;
//	ASYNC(&sem, Wait, (int) &self->cb);
//}
//
//void Critical(Task *self, int unused)
//{
//	//.... critical
//	SYNC(&sem, Signal, 0); // release semaphore
//	ASYNC(self, Non_Critical, 0);
//}
//
//void kickoff(Task *self, int unused)
//{
//	ASYNC(&task1, Non_Critical, 0);
//	ASYNC(&task2, Non_Critical, 0);
//}
///////////////////////////////////////////////////////////////7

void startApp(App *self, int arg) {
    SCI_INIT(&sci0);
    SCI_WRITE(&sci0, "Hello, hello...\n");
	
	ASYNC(self, printKey0, 0);
}

int main() {
    INSTALL(&sci0, sci_interrupt, SCI_IRQ0);
	INSTALL(&can0, can_interrupt, CAN_IRQ0);
    TINYTIMBER(&app, startApp, 0);
    return 0;
}
