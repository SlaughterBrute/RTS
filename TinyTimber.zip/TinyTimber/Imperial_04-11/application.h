#ifndef APPLICATION_H
#define APPLICATION_H

#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdio.h>


#define PERIODS_SIZE 25
#define FREQUENCY_INDICES_SIZE 32
#define BEAT_PATTERN_SIZE FREQUENCY_INDICES_SIZE
typedef struct {
	Object super;
	int key;
	int tempo;
	int periods[PERIODS_SIZE];
	int frequency_indices[FREQUENCY_INDICES_SIZE];
	char beat_pattern[BEAT_PATTERN_SIZE];
	int index;
	Time deadline;
} Tune_Controller;
extern Tune_Controller brother_john_controller;



typedef struct {
    Object super;
	int state;
    char volume;
	int muted;
	Time period;
	Time deadline;
} Pulse_Generator;

extern Pulse_Generator pg0;
extern Serial sci0;

#define DAC_REGISTER ((volatile unsigned char *)0x4000741C)

void change_volume(Pulse_Generator *self, int c);
void mute(Pulse_Generator *self, int unused);
void generate_pulse(Pulse_Generator *self, int unused);
void change_period(Pulse_Generator *self, int period);

void change_key(Tune_Controller *self, int key);
void change_tempo(Tune_Controller *self, int tempo);
void update_frequency(Tune_Controller *self, int unused);




#endif