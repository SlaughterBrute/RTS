#include "application.h"

void change_key(Tune_Controller *self, int key) {
	self->key = key;
}

void change_tempo(Tune_Controller *self, int tempo) {
	self->tempo = tempo;
}

void update_frequency(Tune_Controller *self, int unused) {
	int new_period = self->periods[self->frequency_indices[self->index] + 10 + self->key];
	ASYNC(&pg0, change_period, new_period);
	Time next_frequency_update = MSEC(60000 / self->tempo);
	if(self->beat_pattern[self->index] == 'b') {
		next_frequency_update <<= 1;
	} else if(self->beat_pattern[self->index] == 'c') {
		next_frequency_update >>= 1;
	}
	self->index = (self->index + 1) % 32;
	SEND(next_frequency_update, self->deadline, self, update_frequency, 0);
	AFTER(next_frequency_update - MSEC(100), &pg0, mute, 0);
	AFTER(next_frequency_update, &pg0, mute, 0);
}