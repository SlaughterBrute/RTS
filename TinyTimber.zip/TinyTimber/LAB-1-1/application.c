#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdlib.h>
#include <stdio.h>
#include "application.h"

typedef struct {
    Object super;
    int count;
    char c;
	int frequency_indices[32];
	int period[25];
	int index;
	int value;
	char buffer[100];
} App;

App app = { initObject(), 0, 'X', {0,2,4,0,0,2,4,0,4,5,7,4,5,7,7,9,7,5,4,0,7,9,7,5,4,0,0,-5,0,0,5,0}, {2024,1911,1803,1702,1607,1516,1431,1351,1275,1203,1136,1072,1012,955,901,851,803,758,715,675,637,601,568,536,506},0,0};

void reader(App*, int);
void receiver(App*, int);

Serial sci0 = initSerial(SCI_PORT0, &app, reader);

Can can0 = initCan(CAN_PORT0, &app, receiver);

void receiver(App *self, int unused) {
    CANMsg msg;
    CAN_RECEIVE(&can0, &msg);
    SCI_WRITE(&sci0, "Can msg received: ");
    SCI_WRITE(&sci0, msg.buff);
}

void printKey0(App *self, int unused)
{
	for(int n = 0; n < 32; n++)
	{
		snprintf(self->buffer, 100, "%d", self->period[self->frequency_indices[n]+10]);
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
	}
}

void printKey(App *self, int key)
{ 
	for(int n = 0; n < 32; n++)
	{
		snprintf(self->buffer, 100, "%d", self->period[self->frequency_indices[n]+10+key]);
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
	}
}

void reader(App *self, int c) {
    SCI_WRITE(&sci0, "Rcv: \'");
    SCI_WRITECHAR(&sci0, c);
    SCI_WRITE(&sci0, "\'\n");
	
	char cc = (char) c;
	if(cc == 'q' || cc == 'a') /* increase/decrease volume */
	{
		ASYNC(&pg0, change_volume, c);
	}
	else if(cc == 'w' || cc == 's') /* increase/decrease range */
	{
		ASYNC(&bl, change_range, c);
	}
	else if(cc == 'e') /* enable/disable deadlines */
	{
		ASYNC(&pg0, pulse_deadline, 0);
		ASYNC(&bl, loop_deadline, 0);
	}
	else if(cc == 'm') /* mute/unmute */
	{
		ASYNC(&pg0, mute, 0);
	}
}

void startApp(App *self, int arg) {
    SCI_INIT(&sci0);
    SCI_WRITE(&sci0, "Hello, hello...\n");

	ASYNC(&pg0, generate_pulse, 0);
	ASYNC(&bl, background_loop, 0);

}

int main() {
    INSTALL(&sci0, sci_interrupt, SCI_IRQ0);
	INSTALL(&can0, can_interrupt, CAN_IRQ0);
    TINYTIMBER(&app, startApp, 0);
//    TINYTIMBER(&pg, pulse_1, 0);
    return 0;
}
