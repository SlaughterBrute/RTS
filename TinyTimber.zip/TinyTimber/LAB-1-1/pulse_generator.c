#include "application.h"

Pulse_Generator pg0 = { initObject(), 0, 5, 0, USEC(500), USEC(100), 0 };
Background_Loop bl = { initObject(), 1000, USEC(1300), USEC(1300), 0};

void change_volume(Pulse_Generator *self, int c) {
	char cc = (char)c;
	if(cc == 'q' && self->volume < 0x14) {
		self->volume++;
	} else if(cc == 'a' && self->volume > 1) {
		self->volume--;
	}
}

void mute(Pulse_Generator *self, int unused) {
	if(!self->muted) {
		self->muted = 1;
	} else {
		self->muted = 0;
	}
}

void generate_pulse(Pulse_Generator *self, int unused) {
	
	if(!self->muted) {
		self->state++;
		if(self->state & 1) {
			*DAC_REGISTER = self->volume;
		} else {
			*DAC_REGISTER = 0;
		}
	}
	SEND(self->period, self->deadline, self, generate_pulse, 0);
}


void change_range(Background_Loop *self, int c) {
	char cc = (char)c;
	if(cc == 'w'){// && self->range < 8000) {
		self->range += 500;
	} else if(cc == 's' && self->range > 0) {
		self->range -= 500;
	}
	char buf[100];
	snprintf(buf, 100, "%d", self->range);
	
	SCI_WRITE(&sci0, "Background loop range: ");
    SCI_WRITE(&sci0, buf);
    SCI_WRITE(&sci0, "\n");
}


void background_loop(Background_Loop *self, int unused) {
	for(int i = 0; i < self->range; i++);
	SEND(self->period, self->deadline, self, background_loop, 0);
}

void pulse_deadline(Pulse_Generator *self, int unused)
{
	if(!self->deadline) {
		self->deadline = self->stored_deadline;
		SCI_WRITE(&sci0, "Deadline ON\n");
	} else {
		self->stored_deadline = self->deadline;
		self->deadline = 0;
		SCI_WRITE(&sci0, "Deadline OFF\n");
	}
}

void loop_deadline(Background_Loop *self, int unused)
{
	if(!self->deadline) {
		self->deadline = self->stored_deadline;
	} else {
		self->stored_deadline = self->deadline;
		self->deadline = 0;
	}
}