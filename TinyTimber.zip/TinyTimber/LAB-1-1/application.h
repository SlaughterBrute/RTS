#ifndef APPLICATION_H
#define APPLICATION_H

#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdio.h>


typedef struct {
    Object super;
	int state;
    char volume;
	int muted;
	Time period;
	Time deadline;
	Time stored_deadline;
} Pulse_Generator;

typedef struct {
	Object super;
	int range;
	Time period;
	Time deadline;
	Time stored_deadline;
} Background_Loop;

extern Pulse_Generator pg0;
extern Background_Loop bl;
extern Serial sci0;

#define DAC_REGISTER ((volatile unsigned char *)0x4000741C)

void change_volume(Pulse_Generator *self, int c);
void mute(Pulse_Generator *self, int unused);
void generate_pulse(Pulse_Generator *self, int unused);
//void pulse_0(Pulse_Generator *self, int unused);
void change_range(Background_Loop *self, int c);
void background_loop(Background_Loop *self, int unused);
void pulse_deadline(Pulse_Generator *self, int unused);
void loop_deadline(Background_Loop *self, int unused);



#endif