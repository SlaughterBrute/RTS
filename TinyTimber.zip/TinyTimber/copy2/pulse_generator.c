#include "application.h"

Pulse_Generator pg0 = { initObject(), 10, 0, 1, 0, USEC(500), USEC(100) };

void change_volume(Pulse_Generator *self, int c) {
	char cc = (char)c;
	if(cc == 'q' && self->volume < 0x14) {
		self->volume++;
	} else if(cc == 'a' && self->volume > 1) {
		self->volume--;
	}
}

void set_volume(Pulse_Generator *self, int volume) {
	if(volume >= 0 && volume <= 0x14)
		self->volume = volume;
}

void toggle_master_mute(Pulse_Generator *self, int unused) {
	if(self->master_mute)
		self->master_mute = 0;
	else
		self->master_mute = 1;
}

//void gap_mute(Pulse_Generator *self, int unused) {
//	self->gap_mute = 1;
//}

void gap_mute(Pulse_Generator *self, int channel) { // update: added channel functionality
    if(channel != SYNC(&brother_john_controller, get_channel, 0))
        return;
    self->gap_mute = 1;
}

void gap_unmute(Pulse_Generator *self, int unused) {
	self->gap_mute = 0;
}

void canon_mute(Pulse_Generator *self, int unused) {
	self->canon_mute = 1;
}

void canon_unmute(Pulse_Generator *self, int unused) {
	self->canon_mute = 0;
}

void generate_pulse(Pulse_Generator *self, int state) { // update: use parameter instead of state variable for "state"
    if(!self->gap_mute && !self->master_mute && !self->canon_mute) {
        if(state & 1) {
            *DAC_REGISTER = self->volume;
        } else {
            *DAC_REGISTER = 0;
        }
    }
    SEND(self->period, self->deadline, self, generate_pulse, state + 1);
}

void change_period(Pulse_Generator *self, int period) {
	self->period = USEC(period);
}
