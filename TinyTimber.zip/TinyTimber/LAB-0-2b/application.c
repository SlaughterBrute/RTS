#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    Object super;
    int count;
    char c;
	int index;
	int sum;
	int temp;
	char buffer[100];
} App;

App app = { initObject(), 0, 'X', 0, 0, 0 };

void reader(App*, int);
void receiver(App*, int);

Serial sci0 = initSerial(SCI_PORT0, &app, reader);

Can can0 = initCan(CAN_PORT0, &app, receiver);

void receiver(App *self, int unused) {
    CANMsg msg;
    CAN_RECEIVE(&can0, &msg);
    SCI_WRITE(&sci0, "Can msg received: ");
    SCI_WRITE(&sci0, msg.buff);
}

void reader(App *self, int c) {
    SCI_WRITE(&sci0, "Rcv: \'");
    SCI_WRITECHAR(&sci0, c);
    SCI_WRITE(&sci0, "\'\n");
	
	char cc = (char) c;
	if(cc == 'e')
	{
		self->buffer[self->index] = '\0';
		self->temp = atoi(self->buffer);
		self->sum += self->temp;
		
		snprintf(self->buffer, 100, "%d", self->temp);
		SCI_WRITE(&sci0, "The entered number is ");
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
		
		snprintf(self->buffer, 100, "%d", self->sum);
		SCI_WRITE(&sci0, "The running sum is ");
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
		self->index = 0;
	}
	else if(cc == 'F')
	{
		self->sum = 0;
		snprintf(self->buffer, 100, "%d", self->sum);
		SCI_WRITE(&sci0, "The running sum is ");
		SCI_WRITE(&sci0, self->buffer);
		SCI_WRITE(&sci0, "\n");
		self->index = 0;
	}
	else
	{
		self->buffer[self->index] = cc;
		self->index++;
	}
}

void startApp(App *self, int arg) {
    CANMsg msg;

    CAN_INIT(&can0);
    SCI_INIT(&sci0);
    SCI_WRITE(&sci0, "Hello, hello...\n");
	
    msg.msgId = 1;
    msg.nodeId = 1;
    msg.length = 6;
    msg.buff[0] = 'H';
    msg.buff[1] = 'e';
    msg.buff[2] = 'l';
    msg.buff[3] = 'l';
    msg.buff[4] = 'o';
    msg.buff[5] = 0;
    CAN_SEND(&can0, &msg);
}

int main() {
    INSTALL(&sci0, sci_interrupt, SCI_IRQ0);
	INSTALL(&can0, can_interrupt, CAN_IRQ0);
    TINYTIMBER(&app, startApp, 0);
    return 0;
}
