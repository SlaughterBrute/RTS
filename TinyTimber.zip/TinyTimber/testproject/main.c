#include <stdio.h>

void printInt(int var) {
	printf("%d\n", var);
}

int main(int argc, char **argv)
{
	int a = -5;
	unsigned char c = (unsigned char)a;
	printInt((signed char) c);
	return 0;
}
