#include "TinyTimber.h"
#include "sciTinyTimber.h"
#include "canTinyTimber.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    Object super;
    int count;
    char c;
} App;

App app = { initObject(), 0, 'X'};

typedef struct{
	Object super;
	int state;
} Actuator;

int update(Actuator *self, int new_value)
{
	int old_state = self->state;
	self->state = new_value;
	return  old_state;
}

Actuator actobj = {initObject(), 0};

typedef struct{
	Object super;
	Time period;
	Time deadline;
	int alive;
} TaskObject;
	
TaskObject task1 = {initObject(), USEC(300), USEC(100), 1};
TaskObject task2 = {initObject(), USEC(500), USEC(150), 1};

void task1code(TaskObject *self, int n);
void task2code(TaskObject *self, int n);
void kill(TaskObject *self, int unused);

void kickoff(TaskObject *self, int unused)
{
	BEFORE(USEC(100), &task1, task1code, 10);
	BEFORE(USEC(200), &task2, task2code, 20);
	AFTER(MSEC(100), &task1, kill, 0);
	AFTER(MSEC(200), &task2, kill, 0);
}

void task1code(TaskObject *self, int n)
{
	if(self->alive)
	{
		int old_state = SYNC(&actobj, update, n);
		old_state += 13;
		SEND(self->period, self->deadline, self, task1code, n);
	}
}

void task2code(TaskObject *self, int n)
{
	if(self->alive)
	{
		int old_state = SYNC(&actobj, update, n);
		old_state -= 7;
		SEND(self->period, self->deadline, self, task2code, n);
	}
}

void kill(TaskObject *self, int unused)
{
	self->alive = 0;
}

int main() {
    TINYTIMBER(&task1, kickoff, 0);
    return 0;
}
